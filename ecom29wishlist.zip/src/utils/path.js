const path = require('path');

module.exports = path.dirname(require.main.filename);

// here we get the url path upto src
