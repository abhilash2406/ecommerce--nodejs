const Wishlist = require('../../model/wishlist');
const Product = require('../../model/product');
const Cart = require('../../model/cart');

// // view page controller

// exports.getViewProductPage = (req, res, next) => {
//   Product.fetchAll((products) => {
//     Cart.fetchAll((cartProducts) => {
//       Wishlist.fetchAll((wishlistitems) => {
//         Product.getProductDetailById(req.params.productID, (productData) => {
//           return res.render('shop/view-product', {
//             pageTitle: 'View Product',
//             activeLink: '/',
//             productData,
//             products: products.map((product) => ({
//               ...product,
//               isInCart:
//                 cartProducts.filter(({ id }) => id === product.id).length > 0,
//               isInWishList:
//                 wishlistitems.filter(({ id }) => id === product.id).length > 0,
//             })),
//           });
//         });
//       });
//     });
//   });
// };

// display wishlist controller

exports.getAllProducts = (req, res, next) => {
  Product.fetchAll((products) => {
    Wishlist.fetchAll((wishlsitProducts) => {
      Cart.fetchAll((cartitems) => {
        let formattedProducts = products.filter(({ id }) =>
          wishlsitProducts.map(({ id }) => id).includes(id)
        );
        formattedProducts = formattedProducts.map((p) => ({
          ...p,
          qty: wishlsitProducts.find(({ id }) => id === p.id).qty,
        }));

        res.render('shop/wishlist', {
          pageTitle: 'wishlist',
          cartlength: cartitems.length,
          products: formattedProducts,
          activeLink: '/wishlist',
        });
      });
    });
  });
};

 // add to wishlist 
exports.editwishList = (req, res, next) => {
  const productID = req.body.productID;
  Product.getProductDetailById(productID, (productDetails) => {
    Wishlist.addToWishList(productDetails, () => {
      res.redirect(`/products/${productID}`);
    });
  });
};

//remove from wishlist

exports.removeFromWishList = (req, res, next) => {
  const productID = req.body.productID;
  Wishlist._removeFromWishList(productID, () => {});
  res.redirect(`/wishlist`);
};
